<a href='https://ko-fi.com/G2G0N78P7' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi3.png?v=3' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

![poolcleaner](https://github.com/BuddyNotFound/bbv-poolcleaner/assets/74051918/2cd497b8-aba0-4238-a22f-7ee6540d7778)

**> BBV X WORLD | POOL CLEANER**

**Simple Pool cleaner job for both ESX/QB, works with qb-target/ox-target/bt-target.**

You can add as many jobs/locations as you want easily from the config just using vector3() and the script will generate the rest itself.

As always if you like my work you can leave a :heart: and feedback in comments.
If you find any issues you can report them on in our dc server or github.

> Script Preview

https://streamable.com/kn7k96

> Discord :
> http://discord.bbv.world

